/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.inf30.stockify.bo.almacen;

import pe.edu.pucp.inf30.stockify.model.almacen.Existencias;
import pe.edu.pucp.inf30.stockify.bo.Gestionable;

/**
 *
 * @author DEVlegado
 */

public interface ExistenciasBO extends Gestionable<Existencias> {
    
}
